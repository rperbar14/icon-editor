# v1.0.1

- Updated to Geode v5.11.2 and Geometry Dash 2.2081 (new `Popup` API, C++23)

# v1.0.0

- Initial release
