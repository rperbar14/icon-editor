# Icon Editor (Geode mod)

An in-game icon editor for Geometry Dash, built with [Geode](https://geode-sdk.org).

## Building

1. Install the Geode CLI and SDK: https://docs.geode-sdk.org/getting-started/
2. Make sure `GEODE_SDK` points at your SDK folder.
3. Change `id`, `developer` and `repository` in `mod.json` to your own.
4. Build:

```
geode build
```

The resulting `.geode` file is placed in `build/`. Copy it into your
`Geometry Dash/geode/mods` folder (or use `geode package install`).

## Layout

```
mod.json            mod metadata and settings
CMakeLists.txt      build config
logo.png            mod logo
about.md            shown on the mod page
changelog.md        shown on the mod page
src/main.cpp        garage button hook
src/IconEditorPopup.hpp / .cpp   the editor popup
.github/workflows   CI build for all platforms
```

Targets Geode v5.11.2 (C++23) and Geometry Dash 2.2081.
