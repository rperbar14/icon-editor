# Icon Editor

Adds an **Icon Editor** button to the garage. It opens a popup where you can:

- Pick the icon for **all 9 gamemodes** (cube, ship, ball, UFO, wave, robot, spider, swing, jetpack)
- Change **Color 1**, **Color 2** and the **Glow color**, and toggle glow
- See a **live preview** while you edit
- **Randomize** a whole look with one click
- **Save and load 5 presets**
- Optionally restrict everything to icons you have unlocked (setting)

Press **Apply** to commit the kit to your account.
