#pragma once

#include <Geode/Geode.hpp>
#include <array>
#include <string>

using namespace geode::prelude;

class IconEditorPopup : public geode::Popup {
protected:
    static constexpr int TYPE_COUNT = 9;
    static constexpr int COLOR_COUNT = 107;
    static constexpr int SLOT_COUNT = 5;

    // rows
    enum Row { RowType = 0, RowIcon, RowColor1, RowColor2, RowGlow, RowSlot, RowCount };

    // editor state
    std::array<int, TYPE_COUNT> m_ids{};
    int m_typeIdx = 0;
    int m_color1 = 0;
    int m_color2 = 0;
    int m_glowColor = 0;
    bool m_glow = false;
    int m_slot = 1;

    // widgets
    SimplePlayer* m_preview = nullptr;
    CCLabelBMFont* m_lockLabel = nullptr;
    CCMenuItemToggler* m_glowToggle = nullptr;
    std::array<CCLabelBMFont*, RowCount> m_values{};
    std::array<CCLayerColor*, 3> m_swatches{};

    bool init();

    CCPoint local(float x, float y) const;
    void addRow(int row, char const* title, float y);
    void refresh();

    bool onlyUnlocked() const;
    bool isUnlocked(int typeIdx) const;

    std::string serialize() const;
    bool deserialize(std::string const& data);

    void onArrow(CCObject* sender);
    void onGlowToggle(CCObject* sender);
    void onApply(CCObject* sender);
    void onRandomize(CCObject* sender);
    void onSave(CCObject* sender);
    void onLoad(CCObject* sender);

public:
    static IconEditorPopup* create();
};
