#include "IconEditorPopup.hpp"

#include <random>

namespace {
    constexpr IconType TYPES[9] = {
        IconType::Cube, IconType::Ship, IconType::Ball,
        IconType::Ufo, IconType::Wave, IconType::Robot,
        IconType::Spider, IconType::Swing, IconType::Jetpack
    };
    constexpr char const* NAMES[9] = {
        "Cube", "Ship", "Ball", "UFO", "Wave", "Robot", "Spider", "Swing", "Jetpack"
    };

    // wraps v into the inclusive range [lo, hi]
    int wrapRange(int v, int lo, int hi) {
        int n = hi - lo + 1;
        return ((v - lo) % n + n) % n + lo;
    }

    int randRange(int lo, int hi) {
        static std::mt19937 rng{std::random_device{}()};
        return std::uniform_int_distribution<int>(lo, hi)(rng);
    }

    constexpr float POP_W = 360.f;
    constexpr float POP_H = 290.f;
}

IconEditorPopup* IconEditorPopup::create() {
    auto ret = new IconEditorPopup();
    if (ret->init()) {
        ret->autorelease();
        return ret;
    }
    CC_SAFE_DELETE(ret);
    return nullptr;
}

// converts popup-local coordinates (origin bottom-left) into an offset from the popup center
CCPoint IconEditorPopup::local(float x, float y) const {
    return { x - POP_W / 2.f, y - POP_H / 2.f };
}

bool IconEditorPopup::onlyUnlocked() const {
    return Mod::get()->getSettingValue<bool>("only-unlocked");
}

bool IconEditorPopup::isUnlocked(int typeIdx) const {
    return GameManager::get()->isIconUnlocked(m_ids[typeIdx], TYPES[typeIdx]);
}

void IconEditorPopup::addRow(int row, char const* title, float y) {
    auto titleLabel = CCLabelBMFont::create(title, "goldFont.fnt");
    titleLabel->setScale(0.5f);
    m_mainLayer->addChildAtPosition(titleLabel, Anchor::Center, this->local(250.f, y + 15.f));

    for (int dir = 0; dir < 2; dir++) {
        auto arrow = CCSprite::createWithSpriteFrameName("GJ_arrow_01_001.png");
        arrow->setScale(0.6f);
        arrow->setFlipX(dir == 1);
        auto btn = CCMenuItemSpriteExtra::create(arrow, this, menu_selector(IconEditorPopup::onArrow));
        btn->setTag(row * 2 + dir);
        m_buttonMenu->addChildAtPosition(btn, Anchor::Center, this->local(dir == 0 ? 160.f : 340.f, y));
    }

    auto value = CCLabelBMFont::create("", "bigFont.fnt");
    value->setScale(0.5f);
    m_mainLayer->addChildAtPosition(value, Anchor::Center, this->local(250.f, y - 3.f));
    m_values[row] = value;
}

bool IconEditorPopup::init() {
    if (!Popup::init(POP_W, POP_H)) return false;

    this->setTitle("Icon Editor");

    // load the current kit from the game
    auto gm = GameManager::get();
    m_ids = {
        gm->getPlayerFrame(), gm->getPlayerShip(), gm->getPlayerBall(),
        gm->getPlayerBird(), gm->getPlayerDart(), gm->getPlayerRobot(),
        gm->getPlayerSpider(), gm->getPlayerSwing(), gm->getPlayerJetpack()
    };
    m_color1 = gm->getPlayerColor();
    m_color2 = gm->getPlayerColor2();
    m_glowColor = gm->getPlayerGlowColor();
    m_glow = gm->getPlayerGlow();

    // preview
    m_preview = SimplePlayer::create(1);
    m_preview->setScale(1.7f);
    m_mainLayer->addChildAtPosition(m_preview, Anchor::Center, this->local(75.f, 205.f));

    m_lockLabel = CCLabelBMFont::create("LOCKED", "bigFont.fnt");
    m_lockLabel->setScale(0.4f);
    m_lockLabel->setColor({255, 80, 80});
    m_mainLayer->addChildAtPosition(m_lockLabel, Anchor::Center, this->local(75.f, 160.f));

    // right-hand rows
    this->addRow(RowType,   "Gamemode",   240.f);
    this->addRow(RowIcon,   "Icon",       205.f);
    this->addRow(RowColor1, "Color 1",    170.f);
    this->addRow(RowColor2, "Color 2",    135.f);
    this->addRow(RowGlow,   "Glow Color", 100.f);
    this->addRow(RowSlot,   "Preset Slot", 65.f);

    // color swatches (next to the right arrows of the three color rows)
    float swatchY[3] = {170.f, 135.f, 100.f};
    for (int i = 0; i < 3; i++) {
        auto swatch = CCLayerColor::create({255, 255, 255, 255}, 18.f, 18.f);
        auto p = this->local(300.f, swatchY[i] - 9.f);
        swatch->setPosition({0, 0});
        m_mainLayer->addChildAtPosition(swatch, Anchor::Center, {p.x - 9.f, p.y});
        m_swatches[i] = swatch;
    }

    // glow toggle
    m_glowToggle = CCMenuItemToggler::createWithStandardSprites(
        this, menu_selector(IconEditorPopup::onGlowToggle), 0.6f
    );
    m_glowToggle->toggle(m_glow);
    m_buttonMenu->addChildAtPosition(m_glowToggle, Anchor::Center, this->local(35.f, 110.f));
    auto glowLabel = CCLabelBMFont::create("Glow", "bigFont.fnt");
    glowLabel->setScale(0.45f);
    glowLabel->setAnchorPoint({0.f, 0.5f});
    m_mainLayer->addChildAtPosition(glowLabel, Anchor::Center, this->local(55.f, 110.f));

    // preset buttons (left column)
    auto saveBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Save", "goldFont.fnt", "GJ_button_04.png", 0.7f),
        this, menu_selector(IconEditorPopup::onSave)
    );
    m_buttonMenu->addChildAtPosition(saveBtn, Anchor::Center, this->local(45.f, 75.f));
    auto loadBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Load", "goldFont.fnt", "GJ_button_04.png", 0.7f),
        this, menu_selector(IconEditorPopup::onLoad)
    );
    m_buttonMenu->addChildAtPosition(loadBtn, Anchor::Center, this->local(105.f, 75.f));

    // bottom buttons
    auto randBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Randomize", "goldFont.fnt", "GJ_button_05.png", 0.7f),
        this, menu_selector(IconEditorPopup::onRandomize)
    );
    m_buttonMenu->addChildAtPosition(randBtn, Anchor::Center, this->local(110.f, 28.f));
    auto applyBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Apply", "goldFont.fnt", "GJ_button_01.png", 0.9f),
        this, menu_selector(IconEditorPopup::onApply)
    );
    m_buttonMenu->addChildAtPosition(applyBtn, Anchor::Center, this->local(265.f, 28.f));

    this->refresh();
    return true;
}

void IconEditorPopup::refresh() {
    auto gm = GameManager::get();
    int t = m_typeIdx;

    // preview (colors must be set after the frame is updated)
    m_preview->updatePlayerFrame(m_ids[t], TYPES[t]);
    m_preview->setColor(gm->colorForIdx(m_color1));
    m_preview->setSecondColor(gm->colorForIdx(m_color2));
    if (m_glow) {
        m_preview->setGlowOutline(gm->colorForIdx(m_glowColor));
    } else {
        m_preview->disableGlowOutline();
    }

    int count = std::max(1, gm->countForType(TYPES[t]));
    m_values[RowType]->setString(NAMES[t]);
    m_values[RowIcon]->setString(fmt::format("{} / {}", m_ids[t], count).c_str());
    m_values[RowColor1]->setString(std::to_string(m_color1).c_str());
    m_values[RowColor2]->setString(std::to_string(m_color2).c_str());
    m_values[RowGlow]->setString(std::to_string(m_glowColor).c_str());
    m_values[RowSlot]->setString(fmt::format("Slot {}", m_slot).c_str());

    m_swatches[0]->setColor(gm->colorForIdx(m_color1));
    m_swatches[1]->setColor(gm->colorForIdx(m_color2));
    m_swatches[2]->setColor(gm->colorForIdx(m_glowColor));

    m_lockLabel->setVisible(!this->isUnlocked(t));
}

void IconEditorPopup::onArrow(CCObject* sender) {
    int tag = sender->getTag();
    int row = tag / 2;
    int dir = (tag % 2 == 0) ? -1 : 1;

    switch (row) {
        case RowType:
            m_typeIdx = wrapRange(m_typeIdx + dir, 0, TYPE_COUNT - 1);
            break;
        case RowIcon: {
            int count = std::max(1, GameManager::get()->countForType(TYPES[m_typeIdx]));
            m_ids[m_typeIdx] = wrapRange(m_ids[m_typeIdx] + dir, 1, count);
            break;
        }
        case RowColor1:
            m_color1 = wrapRange(m_color1 + dir, 0, COLOR_COUNT - 1);
            break;
        case RowColor2:
            m_color2 = wrapRange(m_color2 + dir, 0, COLOR_COUNT - 1);
            break;
        case RowGlow:
            m_glowColor = wrapRange(m_glowColor + dir, 0, COLOR_COUNT - 1);
            break;
        case RowSlot:
            m_slot = wrapRange(m_slot + dir, 1, SLOT_COUNT);
            break;
        default:
            break;
    }
    this->refresh();
}

void IconEditorPopup::onGlowToggle(CCObject* sender) {
    // the toggler's state is the one from *before* the click
    m_glow = !static_cast<CCMenuItemToggler*>(sender)->isToggled();
    this->refresh();
}

void IconEditorPopup::onRandomize(CCObject*) {
    int t = m_typeIdx;
    int count = std::max(1, GameManager::get()->countForType(TYPES[t]));

    int pick = randRange(1, count);
    if (this->onlyUnlocked()) {
        for (int i = 0; i < 300; i++) {
            if (GameManager::get()->isIconUnlocked(pick, TYPES[t])) break;
            pick = randRange(1, count);
        }
    }
    m_ids[t] = pick;
    m_color1 = randRange(0, COLOR_COUNT - 1);
    m_color2 = randRange(0, COLOR_COUNT - 1);
    m_glowColor = randRange(0, COLOR_COUNT - 1);
    m_glow = randRange(0, 1) == 1;
    m_glowToggle->toggle(m_glow);
    this->refresh();
}

void IconEditorPopup::onApply(CCObject*) {
    if (this->onlyUnlocked()) {
        for (int i = 0; i < TYPE_COUNT; i++) {
            if (!this->isUnlocked(i)) {
                FLAlertLayer::create(
                    "Locked Icon",
                    fmt::format(
                        "Your <cy>{}</c> icon (#{}) is not unlocked yet.\n"
                        "Pick another one, or disable <cg>Only Allow Unlocked Icons</c> in the mod settings.",
                        NAMES[i], m_ids[i]
                    ),
                    "OK"
                )->show();
                return;
            }
        }
    }

    auto gm = GameManager::get();
    gm->setPlayerFrame(m_ids[0]);
    gm->setPlayerShip(m_ids[1]);
    gm->setPlayerBall(m_ids[2]);
    gm->setPlayerBird(m_ids[3]);
    gm->setPlayerDart(m_ids[4]);
    gm->setPlayerRobot(m_ids[5]);
    gm->setPlayerSpider(m_ids[6]);
    gm->setPlayerSwing(m_ids[7]);
    gm->setPlayerJetpack(m_ids[8]);
    gm->setPlayerColor(m_color1);
    gm->setPlayerColor2(m_color2);
    gm->setPlayerGlowColor(m_glowColor);
    gm->setPlayerGlow(m_glow);

    Notification::create("Icon kit applied!", NotificationIcon::Success)->show();
    this->keyBackClicked(); // closes the popup

    // reload the garage so it shows the new icons
    CCDirector::get()->replaceScene(CCTransitionFade::create(0.25f, GJGarageLayer::scene()));
}

std::string IconEditorPopup::serialize() const {
    std::string out;
    for (int id : m_ids) {
        out += std::to_string(id) + ",";
    }
    out += std::to_string(m_color1) + ",";
    out += std::to_string(m_color2) + ",";
    out += std::to_string(m_glowColor) + ",";
    out += m_glow ? "1" : "0";
    return out;
}

bool IconEditorPopup::deserialize(std::string const& data) {
    auto parts = geode::utils::string::split(data, ",");
    if (parts.size() != TYPE_COUNT + 4) return false;

    std::array<int, TYPE_COUNT + 4> nums{};
    for (size_t i = 0; i < parts.size(); i++) {
        auto res = geode::utils::numFromString<int>(parts[i]);
        if (!res) return false;
        nums[i] = res.unwrap();
    }

    for (int i = 0; i < TYPE_COUNT; i++) {
        int count = std::max(1, GameManager::get()->countForType(TYPES[i]));
        m_ids[i] = wrapRange(nums[i], 1, count);
    }
    m_color1 = wrapRange(nums[TYPE_COUNT + 0], 0, COLOR_COUNT - 1);
    m_color2 = wrapRange(nums[TYPE_COUNT + 1], 0, COLOR_COUNT - 1);
    m_glowColor = wrapRange(nums[TYPE_COUNT + 2], 0, COLOR_COUNT - 1);
    m_glow = nums[TYPE_COUNT + 3] != 0;
    return true;
}

void IconEditorPopup::onSave(CCObject*) {
    Mod::get()->setSavedValue<std::string>(fmt::format("preset-{}", m_slot), this->serialize());
    Notification::create(fmt::format("Saved to slot {}", m_slot), NotificationIcon::Success)->show();
}

void IconEditorPopup::onLoad(CCObject*) {
    auto data = Mod::get()->getSavedValue<std::string>(fmt::format("preset-{}", m_slot), "");
    if (data.empty() || !this->deserialize(data)) {
        Notification::create(fmt::format("Slot {} is empty", m_slot), NotificationIcon::Error)->show();
        return;
    }
    m_glowToggle->toggle(m_glow);
    this->refresh();
    Notification::create(fmt::format("Loaded slot {}", m_slot), NotificationIcon::Success)->show();
}
