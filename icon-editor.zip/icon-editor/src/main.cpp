#include <Geode/Geode.hpp>
#include <Geode/modify/GJGarageLayer.hpp>

#include "IconEditorPopup.hpp"

using namespace geode::prelude;

class $modify(IconEditorGarage, GJGarageLayer) {
    bool init() {
        if (!GJGarageLayer::init()) return false;

        auto winSize = CCDirector::get()->getWinSize();

        auto spr = CircleButtonSprite::createWithSpriteFrameName(
            "GJ_paintBtn_001.png", 0.9f, CircleBaseColor::Green, CircleBaseSize::Medium
        );
        auto btn = CCMenuItemSpriteExtra::create(
            spr, this, menu_selector(IconEditorGarage::onOpenEditor)
        );
        btn->setID("icon-editor-button"_spr);

        auto menu = CCMenu::create();
        menu->setID("icon-editor-menu"_spr);
        menu->setPosition({ winSize.width - 30.f, winSize.height / 2.f - 20.f });
        menu->addChild(btn);
        this->addChild(menu);

        return true;
    }

    void onOpenEditor(CCObject*) {
        IconEditorPopup::create()->show();
    }
};
